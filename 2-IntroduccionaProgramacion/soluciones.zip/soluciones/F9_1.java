package soluciones;

import javax.swing.JOptionPane;

public class F9_1 {
	final static float LIBRA = (float) 0.86, DOLAR = (float) 1.29, YEN = (float) 129.852;

	public static void main(String[] args) {
		String texto = JOptionPane.showInputDialog("Escribe una cantidad en euros");
		double cantidad = Double.parseDouble(texto);

		String moneda = JOptionPane
				.showInputDialog("Escribe la moneda a la que quieres convertir (dolares, libras o yenes)");
		conversor(cantidad, moneda.toLowerCase());
	}

	public static void conversor(double cantidad, String moneda) {
		double res = 0;

		// Este booleano lo utilizo en caso de que alguien, no introduzca un nombre de
		// moneda correcto
		boolean correcto = true;

		// Segun la moneda, calculamos la cantidad
		switch (moneda) {
		case "libras":
			res = cantidad * LIBRA;
			break;
		case "dolares":
			res = cantidad * DOLAR;
			break;
		case "yenes":
			res = cantidad * YEN;
			break;
		default:
			// System.out.println("No has introducido una moneda correcta");
			JOptionPane.showMessageDialog(null, "No has introducido una moneda correcta");
			correcto = false;
		}

		// Solo si es correcto muestra el mensaje
		if (correcto) {
			// System.out.println(cantidad+ " euros en " + moneda + " son " + res);
			JOptionPane.showMessageDialog(null, cantidad + " euros en " + moneda + " son " + res);
		} else {
			// System.out.println("Moneda incorrecta.");
			JOptionPane.showMessageDialog(null, "Moneda incorrecta.");
		}

	}
}
