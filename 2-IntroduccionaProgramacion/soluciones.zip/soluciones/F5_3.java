package soluciones;
import java.util.Scanner;

public class F5_3{
	
	static float suma(float n1, float n2)
	{
		return n1 + n2;
	
	}
	
	static float resta(float n1, float n2)
	{
		return n1 - n2;
	
	}
	
	static float multiplica(float n1, float n2)
	{
		return n1 * n2;
	
	}
	
	static float divide(float n1, float n2)
	{
		return n1 / n2;
	
	}
	
	static int menu(Scanner sc)
	{
		int opcion_menu;
		
		System.out.println();
	    System.out.println("\t1 Sumar");
		System.out.println("\t2 Restar");
		System.out.println("\t3 Multiplicar");
		System.out.println("\t4 Dividir");
		System.out.println("\t5 Salir.");
		
		System.out.print("\n\n\tElija opcion:");
		opcion_menu=Integer.parseInt(sc.nextLine());
	
	    return opcion_menu;
	}
	
	
	public static int leerNumero(Scanner tec, String cadena) {
		int numero;

		System.out.print(cadena);
		numero = Integer.parseInt(tec.nextLine());

		return numero;
	}
	
	
	public static void mostrarMenu()
	{
	   int opcion = 0;	   
	   Scanner sc = new Scanner(System.in);
	  
	   while (opcion != 5)
		{			
		   opcion = menu(sc);
		   float numero1, numero2; 
		 
		   switch (opcion)
		   {
	         case 1:	
	        	 	numero1 = leerNumero(sc, "\nIndica el valor del n�mero 1: ");
	        	 	numero2 = leerNumero(sc, "\nIndica el valor del n�mero 2: ");
	 				System.out.print("Suma de " + numero1 + " y " + numero2 + " es ");
	                System.out.println(suma(numero1, numero2));
	                break;
	         case 2:
	        	 	numero1 = leerNumero(sc, "\nIndica el valor del n�mero 1: ");
	        	 	numero2 = leerNumero(sc, "\nIndica el valor del n�mero 2: ");
	        	 	System.out.print("Resta de " + numero1 + " y " + numero2 + " es ");
	                System.out.println(resta(numero1, numero2));
	                break;
	         case 3:   
	        	 	numero1 = leerNumero(sc, "\nIndica el valor del n�mero 1: ");
	        	 	numero2 = leerNumero(sc, "\nIndica el valor del n�mero 2: ");
		        	System.out.print("Multiplicacion de " + numero1 + " y " + numero2 + " es ");
		            System.out.println(multiplica(numero1, numero2));
		            break;
		     case 4: 
		    	 	numero1 = leerNumero(sc, "\nIndica el valor del n�mero 1: ");
	        	 	numero2 = leerNumero(sc, "\nIndica el valor del n�mero 2: ");
			    	System.out.print("Division de " + numero1 + " y " + numero2 + " es ");
		            System.out.println(divide(numero1, numero2));
		            break;
		     case 5:
		    	 	System.out.print("El programa termina.");
		    	 	break;
		     default:  System.out.println("Valor no v�lido.");
	     	}
	     }
	     sc.close();	  
    }

	public static void main(String args[]){
		mostrarMenu();
	}
	   
	
}

