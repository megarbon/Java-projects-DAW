package soluciones;

import java.util.Scanner;

public class F4_1 {

	    public static void main(String[] args)
	    {
		 Scanner teclado;	
		 teclado = new Scanner(System.in);
		 int numero;
		 
	     numero = leerNumero(teclado, "Indica el valor del n�mero: ");
	     
	     System.out.println("El factorial de " + numero + " es " + factorial(numero) );
	  
	     teclado.close();
	    }
	    
	    public static int leerNumero(Scanner tec, String nombreNumero)
	    {
	 
	        System.out.print(nombreNumero);
	        
	        return Integer.parseInt(tec.nextLine());
	    }
	    
	    public static int factorial(int num)
	    {
	    	int fact=1;
	    	
	    	for(int i=2; i<=num; i++) {
			    fact = fact*i;			   
			}
	    	return fact;
	    }
}
