package soluciones;
import java.util.Scanner;

public class F6{
	
	public static final int MAX_OPC=4;
	
	public static float areaCirculo (float radio){
	       return (float)(Math.pow(radio, 2)*Math.PI);
	}
	
	public static float areaTriangulo (float base, float altura){
	        return base*altura/2;
	}
	
	public static float areaCuadrado (float lado){
	        return lado*lado;
	}

	static int menu(int tope_op, Scanner sc)
	{
		int opcion_menu;
		
		System.out.println();
	    System.out.println("\t1. �rea del c�rculo");
		System.out.println("\t2. �rea del tri�ngulo");
		System.out.println("\t3. �rea del cuadrado");
		System.out.println("\t4. Salir.");
		do
		{
			System.out.print("\n\n\tElija opcion:");
			opcion_menu = Integer.parseInt(sc.nextLine());
		} while (opcion_menu  < 1 || opcion_menu > tope_op);
		// Aqu� hago el chequeo de valor valido de otra forma
	    
		return opcion_menu;
	}
	
	public static void main(String args[]){
		
	   int opcion=0;
	   
	   Scanner sc = new Scanner(System.in);
	   
	   float radio, base, altura, lado;
	  
	   while (opcion != MAX_OPC)
		{
			opcion = menu(MAX_OPC, sc); // Aqu� no hago lectura adelantada, la opci�n 0 nunca se va a dar...
			switch (opcion)
	      	{
	         case 1:
	        	 	 System.out.print("\nIndica el valor del radio: ");
	 				 radio = Float.parseFloat(sc.nextLine());
	 				 
	 				 System.out.print("\nEl �rea del c�rculo de radio "+ radio + " es ");
	                 System.out.println(areaCirculo(radio));
	                 break;
	         case 2:
	        	 	 System.out.print("\nIndica el valor de la base: ");
	        	 	 base = Float.parseFloat(sc.nextLine());
	        	 	 System.out.print("\nIndica el valor de la altura: ");
	        	 	 altura = Float.parseFloat(sc.nextLine());	 
	        	 	 System.out.print("\nEl �rea del tri�ngulo de base "+ base + " y altura " + altura + " es ");
	                 System.out.println(areaTriangulo(base, altura));
	                 break;
	         case 3:
		        	 System.out.print("\nIndica el valor del lado: ");
	        	 	 lado = Float.parseFloat(sc.nextLine());
	        	 	 System.out.print("\nEl �rea del cuadrado de lado "+ lado + " es ");
	                 System.out.println(areaCuadrado(lado));
		             break;
	     	}
	     }
	     sc.close();
	   }
	
}
