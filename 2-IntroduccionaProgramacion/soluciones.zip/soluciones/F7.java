package soluciones;
import javax.swing.JOptionPane;

public class F7 {
    public static void main(String[] args) {
    	
        String texto=JOptionPane.showInputDialog("Introduce un numero");
        int num=Integer.parseInt(texto);
        
        String binario=decimalBinario1(num);
        //System.out.println("El numero "+num+ " en binario es "+binario);
        JOptionPane.showMessageDialog(null, "El numero "+num+ " en binario es "+binario);
        
        binario=decimalBinario2(num);
        //System.out.println("El numero "+num+ " en binario es "+binario);
        JOptionPane.showMessageDialog(null, "El numero "+num+ " en binario es "+binario);
        
        binario=decimalBinario3(num);
        //System.out.println("El numero "+num+ " en binario es "+binario);
        JOptionPane.showMessageDialog(null, "El numero "+num+ " en binario es "+binario);
             
    }
    
    /***** Primera forma, es la que se pide *****/
    
    public static String decimalBinario1 (int numero){
        String binario="";
        int i=numero;

        for(i=numero; i>0; i/=2)  {        
            binario = String.valueOf(i%2)+binario; // Va pegando por delante
            System.out.println(binario);
        }
        
        return binario;
    }
    
    /***** Segunda forma, no es la que se pide *****/
    
    public static String decimalBinario2 (int i){
        String binario="", digito;
          
        while(i>0){
        	if(i%2==1){
                digito="1";
                
            }else{
                digito="0";
            }
        	     	               
            //Se a�ade el digito al principio
            binario=digito+binario;
            i/=2;
        }
       
        return binario;
    }
    
    /***** Tercera forma, no es la que se pide *****/
    
    public static String decimalBinario3 (int numero){
        String binario="", digito;
        int i=numero;

        for(i=numero; i>0; i/=2){
            if(i%2==1) {
                digito="1";
            }else {
                digito="0";
            }
            //Se a�ade el digito al principio
            binario=digito+binario;
        }
        
        return binario;
    }
       
}

