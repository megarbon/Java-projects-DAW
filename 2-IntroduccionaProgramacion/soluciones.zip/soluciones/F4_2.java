package soluciones;

import java.util.Scanner;

public class F4_2 {

	    public static void main(String[] args)
	    {
		 Scanner teclado;	
		 teclado = new Scanner(System.in);
		 int numero;
		 
	     numero = leerNumero(teclado, "Indica el valor del n�mero: ");
	     
	     System.out.println("El factorial de " + numero + " es " + factorial(numero) );
	  
	     teclado.close();
	    }
	    
	    public static int leerNumero(Scanner tec, String nombreNumero)
	    {
	 
	        System.out.print(nombreNumero);
	        
	        return Integer.parseInt(tec.nextLine());
	    }
	    
	    public static double factorial(int num)
	    {
	    	double fact=1; // Si no pongo double se desborda enseguida
	    	
	    	for(int i=num; i>0; i--) {
			    fact = fact*i;
			    if (i!=1)
			    	System.out.print(i + "*");
			    else
			    	System.out.print(i);		    
			}
	    	
	    	System.out.println();
	    	
	    	return fact;
	    }
}
