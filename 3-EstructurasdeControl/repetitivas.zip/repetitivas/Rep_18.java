package repetitivas;

public class Rep_18 {

	public static void main(String[] args) {
		int hora, minuto, segundo;
		final int HORAS = 24, MIN_SEG = 60;

		for (hora = 0; hora < HORAS; hora++) // horas
		// for (hora = 0; true; hora++) // podr�a dejarse sin fin, es un medidor de tiempo...
			for (minuto = 0; minuto < MIN_SEG; minuto++) // minutos
				for (segundo = 0; segundo < MIN_SEG; segundo++) { // segundos
					// Limpiar Pantalla;

					System.out.println(hora + ":" + minuto + ":" + segundo); // escribe hora:minutos:segundos
																				// (actualizandose a medida que va
																				// pasando cada segundo)
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

	}

}
