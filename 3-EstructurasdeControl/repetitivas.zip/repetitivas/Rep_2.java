package repetitivas;

import java.util.Scanner;

public class Rep_2 {

	public static void main(String[] args) {
		int intentos, num_secreto, num_ingresado;
		final int N = 10, LIMITE = 100;

		Scanner sc = new Scanner(System.in);

		intentos = N;

		num_secreto = (int) (Math.random() * LIMITE + 1);
		System.out.println(num_secreto); // En tiempo de desarrollo lo muestro para las pruebas

		System.out.println("Adivine el numero (de 1 a 100):");

		num_ingresado = Integer.parseInt(sc.nextLine());

		while (num_secreto != num_ingresado && intentos > 1) {
			if (num_secreto > num_ingresado)
				System.out.println("Muy bajo");
			else
				System.out.println("Muy alto");

			intentos--;

			System.out.println("Introduzca otro numero. Le quedan " + intentos + " intentos:");
			num_ingresado = Integer.parseInt(sc.nextLine());
		}

		sc.close();

		if (num_secreto == num_ingresado)
			System.out.println("�Exacto! Usted adivin� en " + (N - intentos + 1) + " intentos.");
		else
			System.out.println("El numero era: " + num_secreto);

	}

}
