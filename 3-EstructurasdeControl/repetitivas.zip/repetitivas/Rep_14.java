package repetitivas;

import java.util.Scanner;

public class Rep_14 {

	public static void main(String[] args) {		
		float km1, km2;		
		Scanner sc;

		sc = new Scanner(System.in);
			
// 		Estan en sentido contrario con la misma velocidad
		
//		System.out.println( "Introduce el kilometro donde esta el coche 1: ");
//		km1 = Float.parseFloat(sc.nextLine());
//		System.out.println( "Introduce el kilometro donde esta el coche 2: ");
//		km2 = Float.parseFloat(sc.nextLine());	
				
		km1 = 70;
		km2 = 150;
		
		while (km1 != km2) {
			km1 = km1+1;
			km2 = km2-1;
		}
		
		System.out.println( "Se encuentran en el km:" + km1 ) ;
		
		sc.close();

	}

}
