package repetitivas;

import java.util.Scanner;

public class Rep_1_4 {
	public static void main(String[] args) {
		int num, contador=1;
		float resultado;
		Scanner sc;

		sc = new Scanner(System.in);
		resultado = 1;
		System.out.println("Dime un n�mero:");
		num = Integer.parseInt(sc.nextLine());
			
		do {
			resultado = resultado * contador;
			contador++;
		}
		while (contador <= num);
					
		System.out.println("El resultado es " + resultado);
		
		sc.close();
	}
}
