package repetitivas;

import java.util.Scanner;

public class Rep_13 {

	public static void main(String[] args) {
		float sueldo_por_hora;
		int horas, horas_acum;
		final int DIAS = 6;

		Scanner sc = new Scanner(System.in);

		horas_acum = 0;

		System.out.print("Introduce el sueldo por hora: ");
		sueldo_por_hora = Float.parseFloat(sc.nextLine());

		for (int dia = 1; dia <= DIAS; dia++) {
			System.out.print("�Cu�ntas horas has trabajado el d�a " + dia + "?: ");
			horas = Integer.parseInt(sc.nextLine());
			horas_acum = horas_acum + horas;
		}

		System.out.println("Horas acumuladas en la semana:" + horas_acum);
		System.out.println("Sueldo:" + sueldo_por_hora * horas_acum);

		sc.close();

	}

}
