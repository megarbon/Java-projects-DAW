package repetitivas;

import java.util.Scanner;

public class Rep_4_1 {

	public static void main(String[] args) {
		int num, cantidad_num, cont_negativos, cont_positivos, cont_ceros;

		Scanner sc;

		cont_negativos = 0;
		cont_positivos = 0;
		cont_ceros = 0;

		sc = new Scanner(System.in);

		System.out.println("�Cu�ntos n�meros vas a introducir?:");
		cantidad_num = Integer.parseInt(sc.nextLine());
	
		int i = 1;
		while (i <= cantidad_num) {
			System.out.println("Numero " + i + ":");
			num = Integer.parseInt(sc.nextLine());
			if (num > 0)
				cont_positivos++;
			else if (num < 0)
				cont_negativos++;
			else
				cont_ceros++;
			i++;
		}

		sc.close();

		System.out.println("N�meros positivos:" + cont_positivos);
		System.out.println("N�meros negativos:" + cont_negativos);
		System.out.println("N�meros igual a 0:" + cont_ceros);
	}
}
