package repetitivas;

import java.util.Scanner;

public class Rep_5_2 {

	public static void main(String[] args) {
		String leido;
		Scanner sc;

		sc = new Scanner(System.in);

		do {
			System.out.println("Introduce un solo caracter:");
			leido = sc.nextLine();
		} while (leido.length() != 1);

		while (!leido.isBlank()) {
		// while (!leido.equals(" ")) {
			if ("aeiou".contains(leido.toLowerCase()))
				System.out.println("VOCAL");
			else
				System.out.println("NO VOCAL");
			
			do {
				System.out.println("Introduce un solo caracter:");
				leido = sc.nextLine();
			} while (leido.length() != 1);
		}

		sc.close();
		System.out.println("FIN");

	}

}
