package repetitivas;

import java.util.Scanner;

public class Rep_1_3 {
	public static void main(String[] args) {
		int num, contador;
		float resultado;
		Scanner sc;

		sc = new Scanner(System.in);
		resultado = 1;
		System.out.println("Dime un n�mero:");
		num = Integer.parseInt(sc.nextLine());
		
		contador = num;
		
		while (contador > 1) {
			resultado = resultado * contador;
			contador--;
		}
		
		System.out.println("El resultado es " + resultado);
		
		sc.close();
	}
}
