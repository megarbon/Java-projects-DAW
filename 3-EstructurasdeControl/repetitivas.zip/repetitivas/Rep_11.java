package repetitivas;

import java.util.Scanner;

public class Rep_11 {

	public static void main(String[] args) {
		int numero_es_primo;
		boolean es_primo;
		Scanner sc;

		sc = new Scanner(System.in);

		es_primo = true;
		System.out.println("Introduce un n�mero para comprobar si es primo:");
		numero_es_primo = Integer.parseInt(sc.nextLine());

		for (int num = 2; num <= Math.sqrt(numero_es_primo) && es_primo; num++)
		//for (int num = 2; num < numero_es_primo; num++)
			if (numero_es_primo % num == 0)
				es_primo = false; // En cuanto encontramos un divisor, ya no es primo
		
		if (es_primo)
			System.out.println("Es Primo");
		else
			System.out.println("No es Primo");

		sc.close();

	}

}
