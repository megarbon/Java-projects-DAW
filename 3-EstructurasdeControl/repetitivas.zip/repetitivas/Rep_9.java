package repetitivas;

import java.util.Scanner;

public class Rep_9 {

	public static void main(String[] args) {
		float base, potencia;
		int exponente;
		
		Scanner sc;
		
		sc = new Scanner(System.in);
		
		System.out.print( "Dame la base de la potencia:" );
		base = Float.parseFloat(sc.nextLine());
		
		do {
			System.out.print( "Dame el exponente de la potencia (entero):" );
			exponente = Integer.parseInt(sc.nextLine());
			
			if (exponente<0) 
				System.out.println( "ERROR: El exponente debe ser positivo" );
		} while  (exponente < 0);
		
		potencia = 1;
		// para hacerlo as�, el exponente tiene que ser entero
		for ( int i = 1 ; i <= exponente; i++)
			potencia = potencia * base;
		
		System.out.println( "Potencia:" + potencia) ;
		
		sc.close();
	}

}
