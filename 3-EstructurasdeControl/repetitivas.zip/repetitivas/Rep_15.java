package repetitivas;

public class Rep_15 {

	public static void main(String[] args) {		
		float pago, pago_acum;	
		int mes;
		
		pago_acum = 0;
		pago = 10;
		for ( mes = 1; mes <= 20; mes++ ) {
			pago_acum = pago_acum + pago;			
			System.out.println(" En el mes " + mes + " paga " + pago );
			pago = pago*2;
		}
			
		System.out.println( "Al final de los 20 meses tuvo que pagar: " + pago_acum ) ;

	}

}
