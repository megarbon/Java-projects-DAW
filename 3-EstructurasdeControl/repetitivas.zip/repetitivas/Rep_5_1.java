package repetitivas;

import java.util.Scanner;

public class Rep_5_1 {

	public static void main(String[] args) {
		char car, carM;
		String leido;
		Scanner sc;

		sc = new Scanner(System.in);

		do {
			System.out.println("Introduce un solo caracter:");
			leido = sc.nextLine();
		} while (leido.length() != 1);
		
		car = leido.charAt(0);

		carM = Character.toUpperCase(car);

		while (!Character.isWhitespace(car)) {
			if (carM == 'A' || carM == 'E' || carM == 'I' || carM == 'O' || carM == 'U')
				System.out.println("VOCAL");
			else
				System.out.println("NO VOCAL");

			do {
				System.out.println("Introduce un solo caracter:");
				leido = sc.nextLine();
			} while (leido.length() != 1);
			car = leido.charAt(0);
		}

		sc.close();
		System.out.println("FIN");

	}

}
