package repetitivas;

import java.util.Scanner;

public class Rep_20 {

	public static void main(String[] args) {
		int cant_a_mostrar, num, cant_mostrados, divisor;
		boolean es_primo;
		Scanner sc;

		sc = new Scanner(System.in);

		do {
			System.out.println("Ingrese la cantidad de n�meros primos a mostrar:");
			cant_a_mostrar = Integer.parseInt(sc.nextLine());
		} while (cant_a_mostrar <= 0);

		System.out.println("1:\t2"); // el primer primo es 2, los otros son todos impares...
		cant_mostrados = 1;
		num = 3; // ...a partir de 3

		while (cant_mostrados < cant_a_mostrar) {
			es_primo = true; // supongo que es primo cada uno de ellos hasta que encuentro un divisor

			// num es 3 al arrancar el for
			// el for para en cuanto tengamos un divisor
			for (divisor = num; divisor < Math.sqrt(num) && es_primo; divisor = divisor + 2) // ya sabemos que es impar
				if (num % divisor == 0) // si la divisi�n da exacta...
					es_primo = false; // ...ya no es primo

			if (es_primo) {
				cant_mostrados = cant_mostrados + 1;
				System.out.println(cant_mostrados + ":\t" + num); // cant_mostrados hace de indice
			}

			num = num + 2; // Generamos el siguiente numero a examinar
		}

		sc.close();
	}

}
