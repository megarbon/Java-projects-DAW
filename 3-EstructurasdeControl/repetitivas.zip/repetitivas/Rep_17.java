package repetitivas;

import java.util.Scanner;

public class Rep_17 {

	public static void main(String[] args) {
		int horas_por_trabajador = 0, horas_acum = 0, dias, horas;
		float sueldo_por_hora;
		int trabajadores;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("�Cu�ntos trabajadores tiene la empresa?:");
		trabajadores = Integer.parseInt(sc.nextLine());

		System.out.println("Sueldo por hora de los trabajadores:");
		sueldo_por_hora = Float.parseFloat(sc.nextLine());

		for (int trabajador = 1; trabajador <= trabajadores; trabajador++) {
			System.out.println("\n�Cu�ntos d�as ha trabajado el trabajador " + trabajador + " en la semana?");
			dias = Integer.parseInt(sc.nextLine());

			horas_por_trabajador = 0;

			for (int dia = 1; dia <= dias; dia++) {
				System.out.println("�Cu�ntas horas ha trabajado el trabajador " + trabajador + " el d�a " + dia + "?:");
				horas = Integer.parseInt(sc.nextLine());

				// horas_por_trabajador = horas_por_trabajador + horas;
				horas_por_trabajador += horas;
			}

			// horas_acum = horas_acum + horas_por_trabajador;
			horas_acum += horas_por_trabajador;
			System.out.println(
					" El trabajador " + trabajador + " tiene de sueldo " + horas_por_trabajador * sueldo_por_hora);
		}

		System.out.println("\nEl pago a los " + trabajadores + " trabajadores es: " + horas_acum * sueldo_por_hora);

		sc.close();

	}

}
