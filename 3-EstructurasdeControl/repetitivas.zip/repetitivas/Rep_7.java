package repetitivas;

import java.util.Scanner;

public class Rep_7 {

	public static void main(String[] args) {
		int tabla;
		Scanner sc;
		
		sc = new Scanner(System.in);
			
		System.out.println("�De qu� n�mero quieres mostrar la tabla de multiplicar?:");
		tabla = Integer.parseInt(sc.nextLine());
		
		for ( int num = 1; num <= 10; num++ )
			System.out.println( num + " * " + tabla + " = " + num*tabla);
		
		sc.close();
	}

}
