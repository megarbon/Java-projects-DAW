package repetitivas;

import java.util.Scanner;

public class Rep_19 {

	public static void main(String[] args) {
		int opcion;
		Scanner sc;

		sc = new Scanner(System.in);

		do {
			System.out.println("Men� de recomendaciones");

			System.out.println(" 1. Literatura ");
			System.out.println(" 2. Cine ");
			System.out.println(" 3. M�sica ");
			System.out.println(" 4. Videojuegos ");
			System.out.println(" 5. Salir ");

			System.out.println("\nElija una opci�n (1-5): ");

			opcion = Integer.parseInt(sc.nextLine());

			// procesar esa opci�n
			switch (opcion) {
			case 1:
				System.out.println("\nLecturas recomendables:");
				System.out.println(" + Esper�ndolo a Tito y otros cuentos de f�tbol (Eduardo Sacheri)");
				System.out.println(" + El juego de Ender (Orson Scott Card)");
				System.out.println(" + El sue�o de los h�roes (Adolfo Bioy Casares)");
				break;
			case 2:
				System.out.println("\nPel�culas recomendables:");
				System.out.println(" + Matrix (1999)");
				System.out.println(" + El �ltimo samurai (2003)");
				System.out.println(" + Cars (2006)");
				break;
			case 3:
				System.out.println("\nDiscos recomendables:");
				System.out.println(" + Despedazado por mil partes (La Renga, 1996)");
				System.out.println(" + B�falo (La Misisipi, 2008)");
				System.out.println(" + Gaia (M�go de Oz, 2003)");
				break;
			case 4:
				System.out.println("\nVideojuegos cl�sicos recomendables");
				System.out.println(" + D�a del tent�culo (LucasArts, 1993)");
				System.out.println(" + Terminal Velocity (Terminal Reality/3D Realms, 1995)");
				System.out.println(" + Death Rally (Remedy/Apogee, 1996)");
				break;
			case 5:
				System.out.println("\nGracias, vuelva pronto");
				break;
			default:
				System.out.println("\nOpci�n no v�lida");
				break;
			}

			System.out.println("\nPresione enter para continuar");
			sc.nextLine();
		} while (opcion != 5);

		sc.close();
	}

}
