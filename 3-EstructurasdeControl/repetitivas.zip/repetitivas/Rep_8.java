package repetitivas;

import java.util.Scanner;

public class Rep_8 {

	public static void main(String[] args) {
		int suma_dentro_intervalo=0, cont_fuera_intervalo=0, lim_inf, lim_sup, num;
		boolean igual_limites = false;

		Scanner sc = new Scanner(System.in);

		// Me aseguro que el lim_inf es menor que el lim_sup
		do {
			System.out.println("Introduce el l�mite inferior del intervalo:");
			lim_inf = Integer.parseInt(sc.nextLine());
			
			System.out.println("Introduce el l�mite superior del intervalo:");
			lim_sup = Integer.parseInt(sc.nextLine());

			if (lim_inf > lim_sup)
				System.out.println("ERROR: El l�mite inferior debe ser menor que el superior.");

		} while (lim_inf > lim_sup);

		System.out.print("Introduce un n�mero (0, para salir): ");
		num = Integer.parseInt(sc.nextLine());

		while (num != 0) {
			// Pertenece al intervalo
			if (num > lim_inf && num < lim_sup)
				suma_dentro_intervalo += num;
			else if (num < lim_inf || num > lim_sup)// No pertenece al intervalo
				cont_fuera_intervalo++;

			// N�mero igual a alguno de los l�mites
			if (num == lim_inf || num == lim_sup)
				igual_limites = true;

			System.out.print("Introduce un n�mero (0, para salir): ");
			num = Integer.parseInt(sc.nextLine());
		}

		System.out.println("La suma de los n�meros dentro del intervalo es " + suma_dentro_intervalo);
		System.out.println("La cantidad de n�meros fuera del intervalo es " + cont_fuera_intervalo);

		if (igual_limites)
			System.out.println("Se ha introducido alg�n n�mero igual a los l�mites del intervalo.");
		else
			System.out.println("No se ha introducido alg�n n�mero igual a los l�mites del intervalo.");

		sc.close();
	}

}