package repetitivas;

public class Rep_10 {

	public static void main(String[] args) {
		final int LIMITE = 5, N = 10;

		for (int tabla = 1; tabla <= LIMITE; tabla++) {
			System.out.println("TABLA DEL " + tabla + "\n");
			for (int num = 1; num <= N; num++)
				System.out.println(tabla + " * " + num + " = " + num * tabla);
		}
	}

}
