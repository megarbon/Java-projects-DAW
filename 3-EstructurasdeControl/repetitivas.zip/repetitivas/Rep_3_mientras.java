package repetitivas;

import java.util.Scanner;

public class Rep_3_mientras {

	public static void main(String[] args) {
		int num, suma, cont;
		float media;
		Scanner sc;

		sc = new Scanner(System.in);

		suma = 0;
		cont = 0;

		System.out.println("Teclea un numero (0 para salir):");
		num = Integer.parseInt(sc.nextLine());

		// Con el mientras si el primer n�mero es 0 no va a entrar en el bucle
		while (num != 0) {
			//suma = suma + num;
			suma += num;
			// cont = cont + 1;
			cont++;
			System.out.println("Teclea un numero (0 para salir):");
			num = Integer.parseInt(sc.nextLine());
		}

		sc.close();
		
		// Si cont=0 no puedo realizar la divisi�n
		if (cont > 0)
			media = (float)suma / cont;
		else
			media = 0;

		System.out.println("Suma:" + suma);
		System.out.println("Media:" + media);
	}

}
