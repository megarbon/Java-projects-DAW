package repetitivas;

import java.util.Scanner;

public class Rep_6_for {

	public static void main(String[] args) {
		int num1,num2;
		int aux;
		Scanner sc;
	
		sc = new Scanner(System.in);
		
	
		System.out.println("Introduce el n�mero 1:");
		num1 = Integer.parseInt(sc.nextLine());
		System.out.println("Introduce el n�mero 2:");
		num2 = Integer.parseInt(sc.nextLine());
		
		if (num1 > num2) {
			aux = num1;
			num1 = num2;
			num2 = aux;
		}
	
		if ( num1 % 2 == 1)
			num1 = num1+1;
		
		for (int num = num1; num <= num2; num = num + 2)
			System.out.println( num + " ");
		
		sc.close();
					
	}

}
