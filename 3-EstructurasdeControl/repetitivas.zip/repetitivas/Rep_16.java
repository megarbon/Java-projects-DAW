package repetitivas;

import java.util.Scanner;

public class Rep_16 {

	public static void main(String[] args) {
		int horas_por_semana, horas_acum = 0;
		float sueldo_por_hora;
		int trabajadores;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("�Cu�ntos trabajadores tiene la empresa?:");
		trabajadores = Integer.parseInt(sc.nextLine());
		System.out.println("Sueldo por hora:");
		sueldo_por_hora = Float.parseFloat(sc.nextLine());

		for (int trabajador = 1; trabajador <= trabajadores; trabajador++) {
			System.out.println("\n�Cu�ntas horas ha trabajado el trabajador durante la semana?" + trabajador + " ?");
			horas_por_semana = Integer.parseInt(sc.nextLine());

			horas_acum += horas_por_semana;
			System.out.println(
					" El trabajador " + trabajador + " tiene  sueldo semanal" + horas_por_semana * sueldo_por_hora);
		}

		System.out.println(
				"\nEl pago semanal a los " + trabajadores + " trabajadores es: " + horas_acum * sueldo_por_hora);

		sc.close();

	}

}
