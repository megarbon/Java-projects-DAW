package repetitivas;

import java.util.Scanner;

public class Rep_12 {

	public static void main(String[] args) {
		float cant_mensual, ahorro_acum;
		final int MESES = 12;
		
		Scanner sc;

		sc = new Scanner(System.in);
	
		ahorro_acum = 0;
		for (int mes = 1 ; mes <= MESES; mes++) {
			System.out.println( "�Cu�nto has ahorrado en el mes " + mes + "?:");
			cant_mensual = Float.parseFloat(sc.nextLine());
			ahorro_acum = ahorro_acum + cant_mensual;
			System.out.println( "En el mes " + mes + " llevas ahorrado " + ahorro_acum);
		}
		
		System.out.println( "En el a�o llevas ahorrado " + ahorro_acum);
		sc.close();

	}

}
