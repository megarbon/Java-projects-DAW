package condicionales;

import java.util.Scanner;

public class Cond_8_3 {
	public static void main(String[] args) {
		int nota, edad;
		String sexo;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.print("Introduce la nota: ");
		nota = Integer.parseInt(sc.nextLine());

		System.out.print("Introduce la edad: ");
		edad = Integer.parseInt(sc.nextLine());
		
		System.out.print("Introduce el sexo (F/M): ");
		sexo = sc.nextLine();
		
		
		if (nota >= 5 && edad >= 18 && sexo.toUpperCase().contentEquals("F"))		
				System.out.println("Aceptada");
		else if (nota >= 5 && edad >= 18 && sexo.toUpperCase().contentEquals("M"))
				System.out.println("Posible");
		else
				System.out.println("No Aceptada");

		// Bajo mi punto de vista es menos eficiente que las otras dos, ya que si no entra por la primera
		// vuelve a comparar la nota y la edad con las mismas condiciones
		sc.close();
	}

}
