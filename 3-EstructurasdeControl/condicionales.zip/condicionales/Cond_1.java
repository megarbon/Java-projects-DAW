package condicionales;

import java.util.Scanner;

public class Cond_1 {

	public static void main(String[] args) {
		int num1, num2;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Dime el n�mero 1:");
		num1 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime el n�mero 1:");
		num2 = Integer.parseInt(sc.nextLine());

		if (num1 > num2) {
			System.out.println("N�mero 1 es mayor que n�mero 2");
		} else {
			System.out.println("N�mero 1 no es mayor que n�mero 2");
		}

		sc.close();
	}

}
