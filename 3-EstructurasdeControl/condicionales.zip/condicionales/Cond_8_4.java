package condicionales;

import java.util.Scanner;

public class Cond_8_4 {
	public static void main(String[] args) {
		int nota, edad;
		char sexo;
		String strSexo;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.print("Introduce la nota: ");
		nota = Integer.parseInt(sc.nextLine());

		System.out.print("Introduce la edad: ");
		edad = Integer.parseInt(sc.nextLine());

		if (nota >= 5 && edad >= 18) {
			System.out.print("Introduce el sexo (F/M): ");
			strSexo = sc.nextLine();
			sexo = strSexo.charAt(0);
			if (strSexo.length() == 1 && (sexo == 'F' || sexo == 'M')) {
				if (Character.toUpperCase(sexo) == 'F')
					System.out.println("Aceptada");
				else if (Character.toUpperCase(sexo) == 'M')
					System.out.println("Posible");
				else
					System.out.println("No Aceptada");

			} else
				System.out.println("No ha introducido la entrada correctamente: F o M");
		} else
			System.out.println("No Aceptada");
		
		sc.close();
	}

}
