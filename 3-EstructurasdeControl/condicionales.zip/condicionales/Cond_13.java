package condicionales;

import java.util.Scanner;

public class Cond_13 {
	public static void main(String[] args) {
		int dia, mes, anio, dias_mes = 0;

		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce a�o:");
		anio = Integer.parseInt(sc.nextLine());
		System.out.println("Introduce mes:");
		mes = Integer.parseInt(sc.nextLine());
		System.out.println("Introduce dia:");
		dia = Integer.parseInt(sc.nextLine());
		
		switch (mes) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				dias_mes = 31;
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				dias_mes = 30;
				break;
			case 2:
				if ( anio % 4 == 0 && anio % 100 != 0 ||  anio % 400 == 0 )
					dias_mes = 29;
				else
					dias_mes = 28;
				break;
			default:
				dia = -1; // El mes es incorrecto, para que de error en el if de abajo
		}
		
		System.out.println("dias_mes " + dias_mes);
		
		if (dia < 0 || dia > dias_mes)
			System.out.println("Fecha incorrecta");
		else
			System.out.println("Fecha correcta");	
		
		sc.close();
	}

}
