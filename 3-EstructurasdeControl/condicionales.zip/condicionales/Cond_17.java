package condicionales;

public class Cond_17 {
	public static void main(String[] args) {
		int cara;
		final int NCARAS = 6;
	
		cara = (int) (Math.random() * NCARAS + 1);
		System.out.println(cara);
		
		switch (cara) {
			case 1:
				System.out.println("SEIS");
				break;
			case 2:
				System.out.println("CINCO");
				break;
			case 3:
				System.out.println("CUATRO");
				break;
			case 4:
				System.out.println("TRES");
				break;
			case 5:
				System.out.println("DOS");
				break;
			case 6:
				System.out.println("UNO");
				break;
			default:
				System.out.println("Error: n�mero incorrecto.");
		}

	}

}
