package condicionales;

import java.util.Scanner;

public class Cond_18 {
	public static void main(String[] args) {
		int dia;
		Scanner sc;

		System.out.println("Dime un d�a de la semana (1-7):");

		sc = new Scanner(System.in);
		dia = Integer.parseInt(sc.nextLine());

		switch (dia) {
		case 1:
			System.out.println("lunes");
			break;
		case 2:
			System.out.println("martes");
			break;
		case 3:
			System.out.println("miercoles");
			break;
		case 4:
			System.out.println("jueves");
			break;
		case 5:
			System.out.println("viernes");
			break;
		case 6:
			System.out.println("sabado");
			break;
		case 7:
			System.out.println("domingo");
			break;
		default:
			System.out.println("Error: dia incorrecto.");
		}
		
		sc.close();
	}

}
