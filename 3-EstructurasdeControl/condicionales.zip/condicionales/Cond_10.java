package condicionales;

import java.util.Scanner;

public class Cond_10 {
	public static void main(String[] args) {
		double x1, y1, x2, y2, r1, r2, distancia;

		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Dime coordenada x primera circunferencia:");
		x1 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime coordenada y primera circunferencia:");
		y1 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime radio primera circunferencia:");
		r1 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime coordenada x segunda circunferencia:");
		x2 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime coordenada y segunda circunferencia:");
		y2 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime radio segunda circunferencia:");
		r2 = Integer.parseInt(sc.nextLine());

		distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)); // distancia entre los centros

		// Circunferencias exteriores
		// La distancia entre los centros, d, es mayor que la suma de los radios.
		if (distancia > (r1 + r2))
			System.out.println("Circunferencias exteriores");
		// Circunferencias tangentes exteriores
		// La distancia entre los centros es igual a la suma de los radios.
		else if (distancia == (r1 + r2))
			System.out.println("Circunferencias tangentes exteriores");
		// Circunferencias secantes
		// La distancia es menor que la suma de los radios y mayor que su diferencia.
		else if (distancia < (r1 + r2) && distancia > Math.abs(r1 - r2))
			System.out.println("Circunferencias secantes");
		// Circunferencias tangentes interiores
		// La distancia entre los centros es igual a la diferencia entre los radios.
		else if (distancia == Math.abs(r1 - r2))
			System.out.println("Circunferencias tangentes interiores");
		// Circunferencias interiores
		// La distancia entre los centros es mayor que cero y menor que la diferencia
		// entre los radios.
		else if (distancia > 0 && distancia < Math.abs(r1 - r2))
			System.out.println("Circunferencias interiores");
		// Circunferencias conc�ntricas
		// La distancia = 0.
		else if (distancia == 0)
			System.out.println("Circunferencias conc�ntricas");

		sc.close();
	}

}
