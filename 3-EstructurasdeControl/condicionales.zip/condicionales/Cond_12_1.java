package condicionales;

import java.util.GregorianCalendar;
import java.util.Scanner;

public class Cond_12_1 {
	public static void main(String[] args) {
		int anio;

		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce a�o:");
		anio = Integer.parseInt(sc.nextLine());

		//if ( anio % 4 == 0 && anio % 100 != 0 || anio % 400 == 0 )
		if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 100 == 0 && anio % 400 == 0))
				System.out.println(anio + " El a�o es bisiesto.");
			else
				System.out.println(anio + " El a�o no es bisiesto.");
	

		GregorianCalendar calendar = new GregorianCalendar();
		
			if (calendar.isLeapYear(anio))
				System.out.println(anio + " El a�o es bisiesto.");
			else
				System.out.println(anio + " El a�o no es bisiesto.");

		sc.close();
	}

}
