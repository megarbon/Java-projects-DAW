package condicionales;

import java.util.Scanner;

public class Cond_8_1 {
	public static void main(String[] args) {
		int nota, edad;
		String sexo;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.print("Introduce la nota: ");
		nota = Integer.parseInt(sc.nextLine());

		System.out.print("Introduce la edad: ");
		edad = Integer.parseInt(sc.nextLine());

		System.out.print("Introduce el sexo (F/M): ");
		sexo = sc.nextLine();

		if (nota >= 5 && edad >= 18) {
			if (sexo.toUpperCase().contentEquals("F"))
				System.out.println("Aceptada");
			else if (sexo.toUpperCase().contentEquals("M"))
				System.out.println("Posible");
			else
				System.out.println("No Aceptada");
		} else
			System.out.println("No Aceptada");

		sc.close();
	}

}
