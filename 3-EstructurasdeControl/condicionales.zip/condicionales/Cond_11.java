package condicionales;

import java.util.Scanner;

public class Cond_11 {
	public static void main(String[] args) {
		double ladoA, ladoB, ladoC;

		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce longitud lado A:");
		ladoA = Integer.parseInt(sc.nextLine());

		System.out.println("Introduce longitud lado B:");
		ladoB = Integer.parseInt(sc.nextLine());
		
		System.out.println("Introduce longitud lado C:");
		ladoC = Integer.parseInt(sc.nextLine());

		//Pit�goras: la suma de los cuadrados de los catetos es igual al cuadrado de la hipotenusa
		if (Math.pow(ladoA, 2) + Math.pow(ladoB, 2) == Math.pow(ladoC, 2) || 
			Math.pow(ladoB, 2) + Math.pow(ladoC, 2) == Math.pow(ladoA, 2) ||
			Math.pow(ladoC, 2) + Math.pow(ladoA, 2) == Math.pow(ladoB, 2))
				System.out.println("Tri�ngulo Rect�ngulo");
		else
				System.out.println("No es un tri�ngulo Rect�ngulo");
		
		// Lo de arriba no es incompatible con ninguna de las opciones de abajo
		if (ladoA==ladoB && ladoA==ladoC) // equil�tero: 3 lados iguales
			System.out.println("Tri�ngulo Equil�tero");
		// is�sceles: 2 lados iguales y 1 desigual
		else if ((ladoA == ladoB && ladoA != ladoC) || (ladoB==ladoC && ladoB != ladoA) || (ladoC == ladoA && ladoC != ladoB))
			System.out.println("Tri�ngulo Is�sceles");
		else // los 3 lados son distintos
			System.out.println("Tri�ngulo Escaleno");

		sc.close();
	}

}
