package condicionales;

import java.util.Scanner;

public class Cond_6_1 {
	public static void main(String[] args) {
		String cadena, cadenaMay;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce una cadena:");
		cadena = sc.nextLine();
		
		cadenaMay = cadena.toUpperCase();

		//if (cadenaMay.compareTo(cadena)==0)
		if (cadenaMay.equals(cadena))
			System.out.println("La palabra esta en mayusculas");
		else
			System.out.println("La palabra no esta en mayusculas");

		sc.close();
	}
	
}
