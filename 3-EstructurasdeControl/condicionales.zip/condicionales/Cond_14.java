package condicionales;

import java.util.Scanner;

public class Cond_14 {
	public static void main(String[] args) {
		String tipo;
		float precio_kilo_gen, precio_inicial, precio_final;
		int kilos, tamano;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce el precio inicial por kilos de la UVA (centimos):");
		precio_kilo_gen = Float.parseFloat(sc.nextLine());
		
		precio_inicial = precio_kilo_gen;

		System.out.println("Introduce cuantos kilos has vendido:");
		kilos = Integer.parseInt(sc.nextLine());

		System.out.println("Introduce el tipo de la UVA (A/B):");
		tipo = sc.nextLine(); // En esta versi�n leo como cadena

		if (!(tipo.toUpperCase().equals("A")) && !(tipo.toUpperCase().equals("B")))
			System.out.println("Tipo incorrecto");
		else {
			System.out.println("Introduce el tama�o de la UVA (1/2):");
			tamano = Integer.parseInt(sc.nextLine());

			if (tamano != 1 && tamano != 2)
				System.out.println("Tama�o incorrecto");
			else if (tipo.toUpperCase().equals("A"))
				if (tamano == 1)
					precio_inicial = precio_inicial + 20;
				else
					precio_inicial = precio_inicial + 30;
			else // tipo B, puedo hacerlo porque ya me asegur� de que fuese A o B
				if (tamano == 1)
					precio_inicial = precio_inicial - 30;
				else
					precio_inicial = precio_inicial - 50;

			precio_final = precio_inicial * kilos;
			System.out.println("La ganancia es " + precio_final / 100 + " euros.");		
		}
		
		sc.close();
	}
}
