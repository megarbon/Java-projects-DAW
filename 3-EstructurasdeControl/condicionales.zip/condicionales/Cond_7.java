package condicionales;

import java.util.Scanner;

public class Cond_7 {
	public static void main(String[] args) {
		int base, exponente;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce la base:");
		base = Integer.parseInt(sc.nextLine());
		
		System.out.println("Introduce el exponente:");
		exponente = Integer.parseInt(sc.nextLine());

		if (exponente > 0)
			System.out.println("La potencia es " + Math.pow(base, exponente));
		else if (exponente == 0)
			System.out.println("La potencia es 1");
		else // exponente negativo
			System.out.println("La potencia es " + 1/Math.pow(base, Math.abs(exponente)));
		sc.close();
	}
	
}
