package condicionales;

import java.util.Scanner;

public class Cond_2 {
	public static void main(String[] args) {
		int num;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Dime el n�mero:");
		num = Integer.parseInt(sc.nextLine());

		if (num > 0) {
			System.out.println("El n�mero es positivo");
		} else if (num < 0) {
			System.out.println("El n�mero es negativo");
		} else {
			System.out.println("El n�mero es cero");
		}

		sc.close();
	}
}
