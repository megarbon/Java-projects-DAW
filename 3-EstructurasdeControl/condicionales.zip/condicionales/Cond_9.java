package condicionales;

import java.util.Scanner;

public class Cond_9 {
	public static void main(String[] args) {
		float num1, num2, num3;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Dime el numero 1:");
		num1 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime el numero 2:");
		num2 = Integer.parseInt(sc.nextLine());

		System.out.println("Dime el numero 3:");
		num3 = Integer.parseInt(sc.nextLine());

		if (num1 > num2 && num1 > num3)
			if (num2 > num3)
				System.out.println(num1 + " " + num2 + " " + num3);
			else
				System.out.println(num1 + " " + num3 + " " + num2);
		else if (num2 > num1 && num2 > num3)
			if (num1 > num3)
				System.out.println(num2 + " " + num1 + " " + num3);
			else
				System.out.println(num2 + " " + num3 + " " + num1);
		else if (num3 >= num1 && num3 >= num2)
			if (num1 > num2)
				System.out.println(num3 + " " + num1 + " " + num2);
			else
				System.out.println(num3 + " " + num2 + " " + num1);

		sc.close();
	}

}
