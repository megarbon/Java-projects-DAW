package condicionales;

import java.util.Scanner;

// Si interpretamos que solo tiene que ser una letra lo le�do...
public class Cond_6_2 {
	public static void main(String[] args) {
		String cadena, cadenaMay;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce una cadena:");
		cadena = sc.nextLine();
		
		if (cadena.length() == 1) {
			cadenaMay = cadena.toUpperCase();
			//if (cadenaMay.compareTo(cadena)==0)	
			if (cadenaMay.equals(cadena))
				System.out.println("Es una letra en mayusculas");
			else
				System.out.println("No es una letra en mayusculas");
		}
		else {
			System.out.println("Ha introducido m�s de una letra");
		}

		sc.close();
	}

}
