package condicionales;

import java.util.Scanner;

public class Cond_15 {
	public static void main(String[] args) {
		float coste_por_alumno = 0, coste_autobus;
		int num_alumnos;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("�Cu�ntos alumnos participan en la actividad?:");
		num_alumnos = Integer.parseInt(sc.nextLine());

		if (num_alumnos >= 100) 
				coste_por_alumno = 65;
		// else if (num_alumnos>=50 && num_alumnos<=99) no hace falta <=99
		else if (num_alumnos >= 50) 
				coste_por_alumno = 70;
		else if (num_alumnos >= 30)
				coste_por_alumno = 95;
		else if (num_alumnos < 30) 
				coste_por_alumno = 4000/num_alumnos;
			
			if (num_alumnos>0) {
				coste_autobus = num_alumnos*coste_por_alumno;
				System.out.println("El coste por alumno es " + coste_por_alumno + " euros.");				
				System.out.println( "El coste del autob�s es " + coste_autobus + " euros.");
			}				
			else
				System.out.println( "El n�mero de alumnos debe ser un valor positivo.");
		
		sc.close();
	}
	
}
