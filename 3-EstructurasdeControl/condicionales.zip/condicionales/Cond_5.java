package condicionales;

import java.util.Scanner;

public class Cond_5 {
	public static void main(String[] args) {
		String usuario, clave;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Introduce el usuario:");
		usuario = sc.nextLine();
		
		System.out.println("Introduce la clave:");
		clave = sc.nextLine();

		// if (usuario="pepe" && clave="asdasd") Nooo!!!!
		//if (usuario.compareTo("pepe")==0 && clave.compareTo("asdasd")==0)
		if (usuario.equals("pepe") && clave.equals("asdasd"))
			System.out.println("Has entrado al sistema");
		else
			System.out.println("Usuario/clave incorrectos");

		sc.close();
	}
	
}
