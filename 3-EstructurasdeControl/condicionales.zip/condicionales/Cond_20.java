package condicionales;

import java.util.Scanner;

public class Cond_20 {
	public static void main(String[] args) {
		int peso, zona;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("�Qu� peso tiene el paquete (en gramos)?: ");
		peso = Integer.parseInt(sc.nextLine());

		if (peso > 0 && peso <= 5000) {
			System.out.println("1.- Am�rica del Norte");
			System.out.println("2.- Am�rica Central");
			System.out.println("3.- Am�rica del Sur");
			System.out.println("4.- Europa");
			System.out.println("5.- Asia");
			System.out.println("A que zona se reparte (1-5):");

			zona = Integer.parseInt(sc.nextLine());

			switch (zona) {
			case 1:
				System.out.println("Coste: " + peso * 24 + " euros.");
				break;
			case 2:
				System.out.println("Coste: " + peso * 20 + " euros.");
				break;
			case 3:
				System.out.println("Coste: " + peso * 21 + " euros.");
				break;
			case 4:
				System.out.println("Coste: " + peso * 10 + " euros.");
				break;
			case 5:
				System.out.println("Coste: " + peso * 18 + " euros.");
				break;

			default:
				System.out.println("Zona incorrecta.");
			}

		} else
			System.out.println("Peso incorrecto (no podemos transportar paquetes de m�s de 5 Kg).");

		sc.close();
	}
}
