package condicionales;

import java.util.Scanner;

public class Cond_4 {
	public static void main(String[] args) {
		float dividendo,divisor;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Dime el dividendo:");
		dividendo = Float.parseFloat(sc.nextLine());
		
		System.out.println("Dime el divisor:");
		divisor = Float.parseFloat(sc.nextLine());

		if (divisor == 0) {
			System.out.println("No se puede realizar la divisi�n entre cero");
		} else {
			System.out.println("La divisi�n es " + dividendo/divisor);
		}

		sc.close();
	}
	
	
}
