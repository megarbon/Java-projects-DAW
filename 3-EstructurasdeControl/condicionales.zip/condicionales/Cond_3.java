package condicionales;

import java.util.Scanner;

public class Cond_3 {
	public static void main(String[] args) {
		int num;
		Scanner sc;

		sc = new Scanner(System.in);

		System.out.println("Dime el n�mero:");
		num = Integer.parseInt(sc.nextLine());

		if (num%2 == 0) {
			System.out.println("El n�mero es par");
		} else {
			System.out.println("El n�mero es impar");
		}

		sc.close();
	}
}
